﻿using dotnetstandard_bip39;
using System;

namespace testconsole
{
    class Program
    {
        static void Main(string[] args)
        {
            BIP39 bip39 = new BIP39();

          
        }
    }
}
